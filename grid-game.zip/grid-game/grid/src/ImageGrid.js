// src/components/ImageGrid.js
import React, { useState } from 'react';

const ImageGrid = () => {
  const [images, setImages] = useState(Array(9).fill(null));

  const handleImageUpload = (index) => (event) => {
    const newImages = [...images];
    newImages[index] = event.target.files[0];
    setImages(newImages);
  };

  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '10px' }}>
      {images.map((image, index) => (
        <div key={index}>
          <input type="file" onChange={handleImageUpload(index)} />
          {image && <img src={URL.createObjectURL(image)} alt={`Image ${index}`} style={{ maxWidth: '100%', maxHeight: '100px' }} />}
        </div>
      ))}
    </div>
  );
};

export default ImageGrid;
