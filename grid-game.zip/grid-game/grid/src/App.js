// src/App.js
import React from 'react';
import ImageGrid from './ImageGrid';
import './App.css';


function App() {
  return (
    <div>
      <h1>Image Upload Grid</h1>
      <ImageGrid />
    </div>
  );
}

export default App;
